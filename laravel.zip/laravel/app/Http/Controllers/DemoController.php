<?php


namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class DemoController extends Controller
{
    public function index(Request $request){
        // $id = $request->input('id');
        // $name = $request->input('name');
        // echo $id;
        // echo $name;
        return view('add');
    }


    public function insert(){
    //添加
        /*$insert = "insert into goods set j_id='2',goods_price='88',goods_num='8',goods_money='66'";
        $sql = DB::insert($insert);
        print_r($sql);*/
    //查询
        /*$select = "select * from goods";
        $sql = DB::select($select);
        print_r($sql);*/
    //修改
        /*$update = "update goods set goods_num=100";
        $sql = DB::update($update);
        print_r($sql);*/
    //删除
        /*$delete = "delete from goods where goods_id='1'";
        $sql = DB::delete($delete);
        print_r($sql);*/
    }
}
