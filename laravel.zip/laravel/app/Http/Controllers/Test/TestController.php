<?php

namespace App\Http\Controllers\Test;

use App\Model\CateModel;
use App\Model\TestModel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class TestController extends Controller
{
    //视图
    public function goods(){
        $cate=CateModel::get();
        return view( "goods.shang" , ["cate"=>$cate]);
    }
    //商品添加
    public function goodsDo(Request $request){
        $data=$request->all();
        $red=TestModel::insert($data);
        if($red){
            echo "OK";
        }else{
            echo "NO";
        }
    }
    //列表视图
    public function list(){
        $data=TestModel::simplePaginate(3);
        return view( "goods.list" , ['data'=>$data]);
    }
    //删除
    public function dele(Request $request){
        $id=$request->input('dele');
        $res=TestModel::where("id",$id)->delete();
        if($res){
            echo 1;
        }else{
            echo 2;
        }

    }
     //修改视图
    public function upda(Request $request){
        $id=$request->input('upda');
        $data=TestModel::where("id",$id)->first();
        $cate=CateModel::get();
        return view('goods.upda',["data"=>$data ,"cate"=>$cate]);
    }
    //修改数据
    public function updaDo(Request $request){
        $data = $request->input();
        
        $res=TestModel::where("id",$data['id'])->update($data);
        
        if($res){
            echo "OK";
        }else{
            echo "NO";
        }
    }
    public function update(Request $request){
        $data = $request->input('id');
        $new_data = $request->input('name');
        $res = TestModel::where('id',$data)->update(['name'=>$new_data]);
        if($res){
            echo '1';
        }else{
            echo '2';
        }
    }
}
