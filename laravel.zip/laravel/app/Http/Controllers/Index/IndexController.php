<?php

namespace App\Http\Controllers\Index;
use App\Model\UserModel;
use App\Model\CodeModel;
use App\Model\CateModel;
use App\Model\GoodsModel;
use App\Model\CarModel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class IndexController extends Controller{
	public static $arr=[];
	public function index(){
		// return view("index");
		$data=GoodsModel::limit(2)->get();
		if($data){
			$data=GoodsModel::limit(2)->get()->toArray();
		}else{
			$data=GoodsModel::limit(2)->get();
		}
        
      // $arr=GoodsModel::where("goods_best",1)->select();
      // if($arr){
      // 	$arr=GoodsModel::where("goods_best",1)->get()->toArray();
      // }else{
      // 	$arr=GoodsModel::where("goods_best",1)->get();
      // }
      
      
		// if($arr){
		// 	$arr=GoodsModel::where("islike",1)->get()->toArray();
		// }else{
		// 	$arr=GoodsModel::where("islike",1)->get();
		// }
		// dd($arr);exit;
        return view( "index",[ 'data'=>$data] );
	}
	public function login(){
		return view("login");
	}
	public function cardo(Request $request){
        $goods_id=$request->input('id');
        $arr=DB::table('shop_goods')->where('goods_id',$goods_id)->first();
        if($arr){
            $id = session("uid");
            if(empty($id)){
                echo json_encode([
                    'status'=>1,
                    'msg'=>'请先登录'
                ]);
            }else{
                $is_sell=$arr->is_sale;
                if($is_sell!=1){
                    echo json_encode([
                        'status'=>0,
                        'msg'=>'商品已下架'
                    ]);
                }else{
                    $where=[
                        'goods_id'=>$goods_id,
                        'id'=>$id
                    ];
                    $cart= DB::table('shop_car')->where($where)->first();
                    //库存
                    if($cart){
                        $number=$cart->kucun;
                        $num=$number+1;
                        $goods_num=$arr->sale_num;
                        if($num>$goods_num){
                            echo json_encode([
                                'status'=>0,
                                'msg'=>'库存不足'
                            ]);
                        }else{
                            $cart= DB::table('shop_car')->where($where)->update(['kucun'=>$num]);
                            echo json_encode([
                                'status'=>2,
                                'msg'=>'添加成功'
                            ]);
                        }
                    }else{
                        $data=[];
                        $data['goods_id']=$goods_id;
                        $data['id']=$id;
                        $data['buy_number']=1;
                        $data['ctime']=time();
                        $data['status']=1;
                        $data['del']=0;
                        $data['kucun']=$arr->kucun;
                        DB::table('shop_car')->insert($data);
                        echo json_encode([
                            'status'=>2,
                            'msg'=>'添加成功'
                        ]);
                    }
                   
                }
            }
        }else{
            echo json_encode([
                'status'=>0,
                'msg'=>'没有该商品'
            ]);
        }
    }
	public function car(Request $request){
		$uid = $request->session()->get('uid');
		if(!$request->session()->has('uid')){
			return view("login");
		}else{
			// $id=$request->input('goods_id');
			// $data=[
			// 	"id"=>$uid,
			// 	"goods_id"=>$id,
			// 	"buy_number"=>1,
			// 	"status"=>1,
			// 	"ctime"=>time()
			// ];
			// $res=DB::table("shop_car")->insert($data);
	        $res1=DB::table("shop_car")->join("shop_goods","shop_goods.goods_id","=","shop_car.goods_id")->where("del",0)->where("shop_car.status",1);
	        if($res1){
	        	$res1=DB::table("shop_car")->join("shop_goods","shop_goods.goods_id","=","shop_car.goods_id")->where("del",0)->where("shop_car.status",1)->get()->toArray();
	        }else{
	        	$res1=DB::table("shop_car")->join("shop_goods","shop_goods.goods_id","=","shop_car.goods_id")->where("del",0)->where("shop_car.status",1);
	        }
	        $data=DB::table("shop_goods")->where("goods_hot",1)->limit(4)->get();
			if($data){
				$data=DB::table("shop_goods")->where("goods_hot",1)->limit(4)->get()->toArray();
			}else{
				$data=DB::table("shop_goods")->where("goods_hot",1)->limit(4)->get();
			}
			return view("car",['res1'=>$res1,'data'=>$data]);
		}
		
	}
	public function num(Request $request){		
		$arr=$request->input();
		// print_r($arr);exit;
		$num=$arr['num'];
		$carid=$arr['carid'];
		$number=$arr['kucun'];
		$res=DB::table("shop_car")->where("car_id",$carid)->update(['buy_number'=>$num]);
		if($num>$number){
			$arr=array(
					'status'=>0,
					'msg'=>'库存不足'
				);
			return $arr;
		}else{
			$arr=array(
					'status'=>1,
				);
			$res=DB::table("shop_car")->where("car_id",$carid)->update(['buy_number'=>$num]);
		}
	}
	public function del(Request $request){
		$id=$request->input('id');
		 //print_r($id);exit;
		$res=DB::table("shop_car")->whereIn("car_id",$id)->update(['del'=>1]);
		if($res){
			$arr=array(
					'status'=>1,
					'msg'=>'删除成功'
				);
			return $arr;
		}else{
			$arr=array(
					'status'=>0,
					'msg'=>'删除失败'
				);
			return $arr;
		}
	}
	public function dandel(Request $request){
		$id=$request->input('id');
		 //print_r($id);exit;
		$res=DB::table("shop_car")->where("car_id",$id)->update(['del'=>1]);
		if($res){
			$arr=array(
					'status'=>1,
					'msg'=>'删除成功'
				);
			return $arr;
		}else{
			$arr=array(
					'status'=>0,
					'msg'=>'删除失败'
				);
			return $arr;
		}
	}
	public function account(Request $request){
		$money=array();
        $user_id=session('uid');
        if(empty($user_id)){
            $arr1=array(
				'status'=>0,
				'msg'=>'请先登录',
			);
			return $arr1;
        }
        $data=$request->input('id');
        // dump($data);die;
        //dd(!empty($data));exit;
        if(!empty($data)){
          $car=CarModel::whereIn('shop_car.goods_id',$data)->join('shop_goods','shop_goods.goods_id','=','shop_car.goods_id')->get()->toArray();
          // dump($car);die;
          foreach ($car as $k=>$v){
              if($v['buy_number']>$v['kucun']){
                $all[]=$v['kucun'];
              }
              $goodsIds[]=$v['goods_id'];
          }
          if(!empty($all)){
              $arr1=array(
				'status'=>0,
				'msg'=>'库存不足',
			);
			return $arr1;
          }
          foreach($car as $k=>$v){
              if($v['is_sale']!=1){
                $add[]=$v['title'];
              }
              //总金额
              $money[]=$v['price']*$v['buy_number'];
          }
            if(!empty($add)){
              $arr1=array(
				'status'=>0,
				'msg'=>'已下架',
			);
			return $arr1;
            }
        }else{
			$arr1=array(
				'status'=>0,
				'msg'=>'请选择一件商品',
			);
			return $arr1;
        }
        //订单号
        $order_no=date("YmdHis",time()).rand(1000,9999);
        // print_r($money);die;
        $sum=array_sum($money);
        // print_r($sum);exit;
        //添加进库
            $array=[
                'order_no'=>$order_no,
                'id'=>$user_id,
                'order_amount'=>$sum,
                'order_paytype'=>1,
                'pay_status'=>1,
                'pay_way'=>1,
                'order_status'=>1,
                'ctime'=>time()
            ];
            $res=DB::table('shop_order')->insertGetId($array);
            if(!empty($res)){
		          foreach ($car as $k=>$v){
		              $arr=[
		                  'order_id'=>$res,
		                  'goods_id'=>$v['goods_id'],
		                  'title'=>$v['title'],
		                  'order_no'=>$order_no,
		                  'id'=>$user_id,
		                  'buy_number'=>$v['buy_number'],
		                  'price'=>$sum,
		            	  'ctime'=>time()
		              ];
		              
		              $arr2=DB::table('shop_order_detail')->insert($arr);
		           } 
		           // print_r($car);
		           // die;
		           DB::table('shop_car')->whereIn('goods_id',$data)->update(['status'=>2]);
		           $arr1=array(
						'status'=>1,
						'msg'=>'成功',
						'order_id'=>$res
					);
			return $arr1;
	        }else{
	            $arr1=array(
					'status'=>0,
					'msg'=>'失败',
					'order_id'=>''
				);
			return $arr1;
	        }
   }
   public function order(Request $request){
      $order_id=$request->input('order_id');
      //dump($order_id);die;
      $user_id=$user_id=$request->session()->get('uid');
      $where=[
        'order_id'=>$order_id,
        'id'=>$user_id
      ];
      $arr=DB::table('shop_order_detail')->where($where)->get()->toArray();
      //dump($arr);die;
      $order_price=DB::table('shop_order')->where($where)->get()->toArray()[0];
      // dump($order_price);die;
      return view("payment",['arr'=>$arr,'order_price'=>$order_price]);
   }


   public function address(Request $request){
      $order_id=$request->input();
      // echo $order_id;exit;
      // print_R($order_id);exit;
      $where=[
        'order_id'=>$order_id
      ];
      $arr=DB::table('shop_order')->where($where)->value("address_id");
      //print_R($arr);exit;
      if(empty($arr)){
          echo json_encode(['code'=>0,'msg'=>'请设置收货地址',"id"=>$order_id['id']]);
      }
   }


   public function addressShow(Request $request){
      $order_id=$request->input("order_id");
      $user_id=session('uid');
      $where=[
        'id'=>$user_id,
        'is_del'=>'1'
      ];
      $arrInfo=DB::table('shop_order_address')->where($where)->get();
      return view("address",['arrInfo'=>$arrInfo,'order_id'=>$order_id]);
   }


   public function writeaddr(Request $request){
      $order_id=$request->input("order_id");
      return view("writeaddr",['order_id'=>$order_id]);
   }


   public function address_do(Request $request){
        $data=$request->input();
        $user_id=session('uid');
        $order_id=$data['order_id'];
        //dump($data);die;
        $user_id=$user_id=$request->session()->get('uid');
        if(empty($user_id)){
            echo json_encode(['code'=>2,'msg'=>'请先登录！']);die;
        }
        $data['id']=$user_id;
        $data['is_del']=1;
        $data['ctime']=time();
        $res=DB::table('shop_order_address')->insert($data);
        $address_id=DB::table('shop_order_address')->where('order_id',$order_id)->value('address_id');
        if($res){
          if(!empty($order_id)){
            $arr=DB::table('shop_order')->where('order_id',$order_id)->update(['address_id'=>$address_id]);
          }
            echo json_encode(['code'=>1,'msg'=>'添加成功']);
        }else{
            echo json_encode(['code'=>0,'msg'=>'添加失败']);
        }
    }


    public function  add_del(Request $request){
        $address_id=$request->input('address_id');
        $all=DB::table('shop_order_address')->where('address_id',$address_id)->get()->toArray()[0];
        //dump($all);die;
        if($all->is_default==1){
            return json_encode([
                'code'=>0,
                'msg'=>'请先修改默认地址，再次删除'
            ]);
        }
        $res=DB::table('shop_order_address')->where('address_id',$address_id)->update(['is_del'=>0]);
        if($res){
            return json_encode([
                'code'=>1,
                'msg'=>'删除成功'
            ]);
        }else{
            return json_encode([
                'code'=>0,
                'msg'=>'删除失败'
            ]);
        }
    }




    public function addressupdate(Request $request){
        $address_id=$request->input('address_id');
        // print_R($address_id);exit;
        $res=DB::table('shop_order_address')->where('address_id',$address_id)->get();
        // print_R($res);exit;
        return view('addressupdate',['addressInfo'=>$res]);
    }


    public function address_update(Request $request){
        $data=$request->input();
        $address_id=$request->input("address_id");
        // print_r($order_id);exit;
        $data=[
          'receive_name'=>$data['receive_name'],
          'receive_phone'=>$data['receive_phone'],
          'address'=>$data['address'],
          'address_detail'=>$data['address_detail']
        ];
        $where=[
          'address_id'=>$address_id
        ];
        $res=DB::table('shop_order_address')->where($where)->update($data);
        if($res){
            echo json_encode(['code'=>1,'msg'=>'修改成功']);
        }else{
            echo json_encode(['code'=>0,'msg'=>'修改失败']);
        }
    }
	public function demo(){
		return view("demo");
	}
	public function register(){
		return view("register");
	}
	public function userpage(){
		return view("userpage");
	}
	public function work(){
		return view("work");
	}
	public function shopcontent(Request $request){
		$id=$request->input('id');
		$arr=DB::table("shop_goods")->where("goods_id",$id)->get();

		return view("shopcontent",['arr'=>$arr]);
	}
	 public function allshops(){
        $where=[
            'pid'=>0,
        ];
        $arr=DB::table("shop_category")->where($where)->get();
        $arr1=DB::table("shop_goods")->where("is_tell",1)->get();
        return view("all",['arr'=>$arr,'arr1'=>$arr1]);
    }
    public function test(Request $request){
        $arrIds=DB::table('shop_category')->select("cate_id")->where("pid",0)->get();
        $cate_id=$request->input('id');
        if(empty($cate_id)){
        	$goodsInfo=DB::table("shop_goods")->where("is_tell",1)->get();
        }else{
        	 $this->get($cate_id);
        // var_dump($cate_id);die;
        array_unshift(self::$arr,$cate_id);
        $goodsInfo=DB::table('shop_goods')->whereIn("cate_id",self::$arr)->orderBy("price")->get();
        }
       
        // var_dump($goodsInfo);
        $view=view("shopsli",['goodsInfo'=>$goodsInfo]);
        $content=response($view)->getContent();
        $arr['info']=$content;
        return $arr;


    }
    public function get($id){
        $arrNews=DB::table('shop_category')->select("cate_id")->where("pid",$id)->get();
        if(count($arrNews)>0){
            foreach($arrNews as $key=>$value){
                $cateId=$value->cate_id;
                $arrids=$this->get($cateId);
            }
        }
        foreach($arrNews as $value){
            $cate_id=$value->cate_id;
            array_push(self::$arr,$cate_id);
        }
       
}

	//注册
	public function doadd(Request $request){
		$arr=$request->input();
		$tel=$arr['tel'];
		$pwd=$arr['pwd'];
		$conpwd=$arr['conpwd'];
		$code=$arr['code'];
		if($pwd!=$conpwd){
			$arr=array(
					'status'=>0,
					'msg'=>'密码不一致'
				);
			return $arr;
		}
		//验证唯一
		$arr=UserModel::where("name",$tel)->first();
		if(!empty($arr)){
			$arr=array(
					'status'=>0,
					'msg'=>'手机已注册过了'
				);
			return $arr;
		}
		//验证码
		$time=time();
		$arrInfo=DB::table("code")->select("*")->where("code",$code)->where("timeout",">",$time)->where("tel",$tel)->where("status",1)->first();
		if(empty($arrInfo->id)){
			$arr=array(
					'status'=>0,
					'msg'=>'验证码错误',
				);
			return $arr;
		}
		//入库
		$pwd=md5($pwd);
		$arrInfo=array(
				'name'=>$tel,
				'pwd'=>$pwd
			);
		$bol=DB::table("user")->insert($arrInfo);
		if($bol){
			$arr=array(
					'status'=>1,
					'msg'=>'注册成功'
				);
			return $arr;
		}else{
			$arr=array(
					'status'=>0,
					'msg'=>'注册失败'
				);
			return $arr;
		}
	}
	//登录
	public function loginDo(Request $request){
	    $data=$request->input();
	    $arr=UserModel::where('name',$data['txtAccount'])->first();
	    if($arr){
	        if($arr['pwd'] == md5($data['txtPassword'])){
	        	//dd($arr);exit;
	        	$id=$arr->id;
	        	$name=$arr->name;
	        	session(['uid'=>$id,'name'=>$name]);
	            return $array=[
	                'status'=>1,
	                "msg"=>"登录成功"
	            ];
	        }else{
	            return $array=[
	                'status'=>2,
	                "msg"=>"手机号或密码错误"
	            ];
	        }
	    }else{
	        return $array=[
	            'status'=>2,
	            "msg"=>"手机号或密码错误"
	        ];
	    }
	}
	public function getCode(Request $request){
		$tel=$request->input("tel");
		$num=rand(1000,9999);
		$obj=new \send();
		$bol=$obj->show($tel,$num);
		// echo $bol;exit;
		if($bol==100){
			$arr=array(
					'tel'=>$tel,
					'code'=>$num,
					'timeout'=>time()+240,
					'status'=>1,
				);
			$bol=CodeModel::insert($arr);
			$arr1=array(
					'status'=>0,
					'msg'=>'验证码发送成功'
				);
			return $arr1;
		}else{
			$arr1=array(
					'status'=>1,
					'msg'=>'验证码发送失败'
				);
			return $arr1;
		}
	}
	public function addli(Request $request){
        $arr=array();
        $page=$request->input("page",1);
        $pageNum=2;
        $offset=($page-1)*$pageNum;
        $arrDataInfo=DB::table("shop_goods")->offset($offset)->limit($pageNum)->get();//每页的数据


        $totalData=DB::table("shop_goods")->count();
        $pageTotal=ceil($totalData/$pageNum);//总页数


        $objview=view("goodsli",['info'=>$arrDataInfo]);
        $content=response($objview)->getContent();


        $arr['info']=$content;
        $arr['page']=$pageTotal;
        return $arr;
    }
}