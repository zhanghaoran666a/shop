<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::any('/php','Test\TestController@php');
Route::any('/goods','Test\TestController@goods');
Route::any('/goodsDo','Test\TestController@goodsDo');
Route::any('/list','Test\TestController@list');
Route::get('/dele','Test\TestController@dele');
Route::get('/upda','Test\TestController@upda');
Route::any('/updaDo','Test\TestController@updaDo');
Route::any('/update','Test\TestController@update');
Route::any('/index','Index\IndexController@index');
Route::any('/login','Index\IndexController@login');
Route::any('/register','Index\IndexController@register');
Route::any('/loginDo','Index\IndexController@loginDo');
Route::any('/doadd','Index\IndexController@doadd');
Route::any('/userpage','Index\IndexController@userpage');
// Route::any('/tuijian','Index\IndexController@tuijian');
Route::any('/getCode','Index\IndexController@getCode');
Route::any('/demo','Index\IndexController@demo');
Route::any('/allshops','Index\IndexController@allshops');
Route::any('/addli','Index\IndexController@addli');
Route::any('/test','Index\IndexController@test');
Route::any('/shopcontent','Index\IndexController@shopcontent');
Route::any('/work','Index\IndexController@work');
Route::any('/car','Index\IndexController@car');
Route::any('/cardo','Index\IndexController@cardo');
Route::any('/num','Index\IndexController@num');
Route::any('/del','Index\IndexController@del');
Route::any('/account','Index\IndexController@account');
Route::any('/dandel','Index\IndexController@dandel');
Route::any('/order','Index\IndexController@order');
Route::any('/address','Index\IndexController@address');
Route::any('/addressShow','Index\IndexController@addressShow');
Route::any('/writeaddr','Index\IndexController@writeaddr');
Route::any('/address_do','Index\IndexController@address_do');
Route::any('/add_del','Index\IndexController@add_del');
Route::any('/addressupdate','Index\IndexController@addressupdate');
Route::any('/address_update','Index\IndexController@address_update');