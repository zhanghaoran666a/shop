<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="/js/jquery.min.js"></script>
</head>
<body>
    <table border="1">
        <input type="hidden" id="goods_id" value="<?php echo e($data['id']); ?>">
        <tr>
            <td>名称</td>
            <td><input type="text" id="name" value="<?php echo e($data['name']); ?>"></td>
        </tr>
        <tr>
            <td>分类</td>
            <td>
                <select id="cate">
                    <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($v->id == $data['cate']): ?>
                            <option value="<?php echo e($v->id); ?>" selected><?php echo e($v->name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($v->id); ?>"><?php echo e($v->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>描述</td>
            <td>
                <input type="text" id="describe" value="<?php echo e($data['describe']); ?>">
            </td>
        </tr>
        <tr>
            <td>是否上架</td>
            <td>
                <?php if($data['is_putaway'] == 1): ?>
                    <input type="radio" name="is_putaway" value="1" checked>是
                    <input type="radio" name="is_putaway" value="2">否
                <?php else: ?>
                    <input type="radio" name="is_putaway" value="1" checked>是
                    <input type="radio" name="is_putaway" value="2">否
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td>是否热卖</td>
            <td>
                <?php if($data['ishot'] == 1): ?>
                    <input type="radio" name="ishot" value="1" checked>是
                    <input type="radio" name="ishot" value="2">否
                <?php else: ?>
                    <input type="radio" name="ishot" value="1">是
                    <input type="radio" name="ishot" value="2" checked>否
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" id="sub" value="修改"></td>
        </tr>
    </table>
</body>
</html>
<script type="text/javascript">
    $(function(){
        $("#sub").on("click",function(){
            var id=$("#goods_id").val();
            var name=$("#name").val();
            var cate=$("#cate").val();
            var describe=$("#describe").val();
            var is_putaway=$("input[name='is_putaway']:checked").val();
            var ishot=$("input[name='ishot']:checked").val();
            
            $.ajax({
                url:"/updaDo",
                data:{id:id,name:name,cate:cate,describe:describe,is_putaway:is_putaway,ishot:ishot},
                type:"post",
                async:true,
                success:function(msg){
                   console.log(msg);
                   //return false;
                    if(msg == "OK" ){
                        location.href="/list";
                    }else{
                        location.href="/list";
                    }
                }
            });
        })
    })
</script>