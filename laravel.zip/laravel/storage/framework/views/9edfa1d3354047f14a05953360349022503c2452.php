<?php
	header("content-type:text/html;charset=utf-8");
	$arr=array(
				array("id"=>1,"name"=>"lisi","age"=>20),
				array("id"=>2,"name"=>"lisi","age"=>50),
				array("id"=>3,"name"=>"lisi","age"=>10),
				array("id"=>4,"name"=>"lisi","age"=>9),
				array("id"=>5,"name"=>"lisi","age"=>4),
			);
	foreach($arr as $k=>$v){
		$arr1[]=$v['age'];
	}
	sort($arr1);
	// print_r($arr1);
	foreach($arr as $key=>$value){
		// print_r($value);
		$arr2[$value['age']]=$value;
	}
	 print_r($arr2);
	foreach($arr1 as $v){
		//print_r($v);
		$arr3[]=$arr2[$v];
	}
	print_r($arr3);
?>